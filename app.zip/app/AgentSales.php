<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AgentSales extends Model
{
    protected $guarded = [];
    protected $table = 'add_sales';
    public $timestamps = false;

}
