<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Settings;
use Carbon\Carbon;
use App\Wallet;

class SettingsController extends Controller
{
	public function index(){
		$comm = Settings::where('type', 'self funded agents')->get();
		$funded = Settings::where('type', 'funded agents')->get();
		return view('settings.com.index', ['comm' => $comm, 'funded' => $funded]);
	}
    public function commission(){
    	return view('settings.com.commissions');
    }

    public function store(Request $r){
    	$validatedData = $r->validate([
	        'comm_percent' => 'required',
	        'value' => 'required',
	        'type' => 'required'
        ]);
    	
    	if($validatedData){
    		$c = new Settings;
    		$c->comm = $r->get('comm_percent');
    		$c->value = $r->get('value');
    		$c->created_at = Carbon::now();
    		$c->type = $r->get('type');
    		
    		if ($c->save()) {
                return back()->with('success','Commission added successfully.');
            } else {
                return back()->with('error','Commission Not updated');
            }
    	}


    }

    public function edit($id){
    	$value = Settings::find($id);
    	return view('settings.com.edit', ['value' => $value]);
    }

    public function update(Request $r){
    	$validatedData = $r->validate([
	        'comm_percent' => 'required',
	        'value' => 'required',
	        'type' => 'required'
        ]);
    	
    	if($validatedData){
    		$c = Settings::find($r->get('id'));

    		$c->comm = $r->get('comm_percent');
    		$c->value = $r->get('value');
    		$c->created_at = Carbon::now();
    		$c->type = $r->get('type');
    		
    		if ($c->save()) {
                return back()->with('success','Commission added successfully.');
            } else {
                return back()->with('error','Commission Not updated');
            }
    	}
    }

    public function destroy($id){
    	$comm = Settings::find($id);
        
        if(!is_null($comm)) {

            $comm->delete();
            return back()->with('success','Sale Deleted successfully.');
        } else {
            return back()->with('error','Sale Not Deleted');
        }
    }
}
