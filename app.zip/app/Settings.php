<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Settings extends Model
{
    protected $guarded = [];
    protected $table = 'commission';
    public $timestamps = false;
}
