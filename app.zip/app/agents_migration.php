<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class agents_migration extends Model
{
    protected $table = 'agents';
}
